<?php
if(!$IWEB_SHOP_IN) {
	die('Hacking attempt');
}

//引入语言包
$a_langpackage=new adminlp;

//数据表定义区
$t_remind_info = $tablePreStr."remind_info";

//读写分离定义方法
$dbo = new dbex;
dbtarget('r',$dbServs);

$sql = "select * from `$t_remind_info` where user_id=0 order by remind_time desc";
$result = $dbo->fetch_page($sql,13);

//$cat_info = get_news_cat_list($dbo,$t_article_cat);
//print_r($cat_info);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" type="text/css" href="skin/css/admin.css">
<link rel="stylesheet" type="text/css" href="skin/css/main.css">
<script type='text/javascript' src="skin/js/jy.js"></script>
<style>
td span {color:red;}
.green {color:green;}
.red {color:red;}
</style>
</head>
<body>
<div id="maincontent">
<?php  include("messagebox.php");?>
	<div class="wrap">
	<div class="crumbs"><?php echo $a_langpackage->a_location; ?> &gt;&gt; <?php echo $a_langpackage->a_promotion_manage;?> &gt;&gt; <?php echo $a_langpackage->a_set_message; ?></div>
        <hr />
	<div class="infobox">
	<h3><span class="left"><?php echo $a_langpackage->a_set_message; ?></span> <span class="right" style="margin-right:15px;"><a href="m.php?app=remind_add"><?php echo $a_langpackage->a_message_add; ?></a></span></h3>
    <div class="content2">
		<form action="a.php?act=news_catdel" name="form1" id="form1" method="post">
		<table class="list_table">
		  <thead>
			<tr style=" text-align:center">
				<th width="30px"><input type="checkbox" onclick="checkall(this,'rinfo_id[]');" value='' /></th>
				<th width="30px">ID</th>
				<th width="" align="left"><?php echo $a_langpackage->a_message_conten; ?></th>
				<th width="60px"><?php echo $a_langpackage->a_operate; ?></th>
			</tr>
			</thead>
			<tbody>
			<?php if($result['result']) {
			foreach($result['result'] as $value) { ?>
			<tr style=" text-align:center">
				<td width="30px"><input type="checkbox" name="cat_id[]" value="<?php echo $value['rinfo_id'];?>"/></td>
				<td width="30px"><?php echo $value['rinfo_id'];?></td>
				<td width="" align="left"><?php echo $value['remind_info'];?></td>
				<td width="60px">
					<a href="m.php?app=remind_edit&id=<?php echo $value['rinfo_id'];?>"><?php echo $a_langpackage->a_update; ?></a><br />
					<a href="a.php?act=remind_del&id=<?php echo $value['rinfo_id'];?>" onclick="return confirm('<?php echo $a_langpackage->a_message_del; ?>');"><?php echo $a_langpackage->a_dele; ?></a>
				</td>
			</tr>
			<?php }?>
			<tr>
				<td colspan="6" class="center"><?php include("m/page.php"); ?></td>
			</tr>
			<?php } else { ?>
			<tr>
				<td colspan="6" class="center"><?php echo $a_langpackage->a_nonews_list; ?>!</td>
			</tr>
			<?php } ?>
		</table>
		</form>
	   </div>
	  </div>
	 </div>
</div>
<div style="color:red; display:none; width:270px; margin:5px auto;" id="ajaxmessageid">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $a_langpackage->a_loading; ?></div>
<script language="JavaScript" src="../servtools/ajax_client/ajax.js"></script>
<script language="JavaScript">
<!--
function toggle_show(obj,id) {
	var re = /yes/i;
	var src = obj.src;
	var isshow = 1;
	var sss = src.search(re);
	if(sss > 0) {
		isshow = 0;
	}
	ajax("a.php?act=news_isshow_toggle","POST","id="+id+"&s="+isshow,function(data){
		if(data) {
			obj.src = '../skin/default/images/'+data+'.gif';
		}
	});
}
var inputs = document.getElementsByTagName("input");

function delcheck(){
	var checked = false; 
    for (var i = 0; i < inputs.length; i++) 
    { 
    	if (inputs[i].checked == true) 
        {
            checked = true;
            if(confirm('<?php echo $a_langpackage->a_exe_message; ?>')){
            	break; 
                }else{
                	return false;
                	break; 
                    }
        }  
    } 
    if (!checked) 
    { 
        ShowMessageBox("请至少选择一个标题！",'0'); 
        return false; 
    }
    return true;
}
//-->
</script>
</body>
</html>