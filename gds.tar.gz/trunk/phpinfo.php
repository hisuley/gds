<?php

	phpinfo();
?>
